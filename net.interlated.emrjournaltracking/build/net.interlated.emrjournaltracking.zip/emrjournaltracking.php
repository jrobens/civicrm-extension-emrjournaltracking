<?php

/**
 *  Journal tracking, main function
 * 
 * jrobens@interlated.com.au 201207
 * 
 */
require_once 'emrjournaltracking.civix.php';
require_once 'EmrJournaltrackingVal.php';

/**
 * Implementation of hook_civicrm_config
 */
function emrjournaltracking_civicrm_config(&$config) {
  _emrjournaltracking_civix_civicrm_config($config);
}

/**
 * Implementation of hook_civicrm_xmlMenu
 *
 * @param $files array(string)
 */
function emrjournaltracking_civicrm_xmlMenu(&$files) {
  _emrjournaltracking_civix_civicrm_xmlMenu($files);
}

/**
 * Implementation of hook_civicrm_install( )
 */
function emrjournaltracking_civicrm_install() {
  $emrjournaltrackingRoot =
      dirname(__FILE__) . DIRECTORY_SEPARATOR;

  $emrjournaltrackingSql =
      $emrjournaltrackingRoot . DIRECTORY_SEPARATOR .
      'emrjournaltracking_install.sql';

  CRM_Utils_File::sourceSQLFile(
      CIVICRM_DSN, $emrjournaltrackingSql
  );

  // rebuild the menu so our path is picked up
  CRM_Core_Invoke::rebuildMenuAndCaches();
}

/**
 * Implementation of hook_civicrm_uninstall( )
 */
function emrjournaltracking_civicrm_uninstall() {
  $emrjournaltrackingRoot =
      dirname(__FILE__) . DIRECTORY_SEPARATOR;

  $emrjournaltrackingSql =
      $emrjournaltrackingRoot . DIRECTORY_SEPARATOR .
      'emrjournaltracking.uninstall.sql';

  CRM_Utils_File::sourceSQLFile(
      CIVICRM_DSN, $emrjournaltrackingSql
  );

  // rebuild the menu so our path is picked up
  CRM_Core_Invoke::rebuildMenuAndCaches();
}

require_once 'CRM/Contact/Form/Search/Interface.php';

/**
 * Search interface for performing queries against contacts.
 * 
 */
class net_interlated_emrjournaltracking implements CRM_Contact_Form_Search_Interface {

  protected $_formValues;

  /**
   * 
   * 
   * @param type $formValues
   */
  function __construct(&$formValues) {
    if (!empty($formValues)) {
      $this->_formValues = $formValues;
    }

    /**
     * Define the columns for search result rows
     * 
     * Used to define the CSV export.
     */
    $this->_columns = array(
      ts('Membership Number') => 'id',
      ts('Name') => 'name',
      ts('Line 1') => 'street_address',
      ts('Line 2') => 'supplemental_address_1',
      ts('Line 3') => 'supplemental_address_2',
      ts('City') => 'city',
      ts('State') => 'state',
      ts('Post Code') => 'postal_code',
      ts('Country') => 'country',
    );

    // Custom fields see ActivitySearch.php
  }

  /**
   * Define the smarty template used to layout the search form and results listings.
   */
  function templateFile() {
    return 'JournalResults.tpl';
  }

  /**
   * Present a form to the user with.
   * TODO - not used.
   * 
   * @param type $form
   */
  function buildForm(&$form) {
    /**
     * You can define a custom title for the search form
     */
    $this->setTitle('Find Latest EMR Activities');

    /**
     * Define the search form fields here
     */
    // Allow user to choose which type of contact to limit search on
    $form->add('select', 'contact_type', ts('Find...'), CRM_Core_SelectValues::contactType());

    // Text box for Activity Subject
    $form->add('text', 'activity_subject', ts('Activity Subject'));

    // Select box for Activity Type
    $activityType =
        array('' => ' - select activity - ') +
        CRM_Core_PseudoConstant::activityType();

    $form->add('select', 'activity_type_id', ts('Activity Type'), $activityType, false);

    // textbox for Activity Status
    $activityStatus =
        array('' => ' - select status - ') +
        CRM_Core_PseudoConstant::activityStatus();

    $form->add('select', 'activity_status_id', ts('Activity Status'), $activityStatus, false);

    // Activity Date range
    $form->addDate('start_date', ts('Activity Date From'), false, array('formatType' => 'custom'));
    $form->addDate('end_date', ts('...through'), false, array('formatType' => 'custom'));


    // Contact Name field
    $form->add('text', 'sort_name', ts('Contact Name'));

    /**
     * If you are using the sample template, this array tells the template fields to render
     * for the search form.
     */
    $form->assign('elements', array('contact_type', 'activity_subject', 'activity_type_id',
      'activity_status_id', 'start_date', 'end_date', 'sort_name'));
  }

  /*
   * -- membership number, name, line 1, line 2, line 3, city, state, code, country
    -- supplemental_address3 doesn't seem to be used.
    -- Could check join_date, start_date, end_date etc for 'is financial' or membership_status table?
    select cc.id, CONCAT_WS(' ', first_name, last_name) as name, street_address, supplemental_address_1, supplemental_address_2, city, csp.abbreviation as State, postal_code, country.name as Country
    FROM civicrm_contact cc
    LEFT JOIN civicrm_address ca ON cc.id = ca.contact_id
    LEFT JOIN civicrm_membership cm ON cc.id = cm.contact_id
    LEFT JOIN civicrm_state_province csp ON ca.state_province_id = csp.id
    LEFT JOIN civicrm_country country ON ca.country_id = country.id

    -- rules for 'journal eligible'
    -- 1= standard member, 7 = life member
    WHERE cm.membership_type_id IN (1,7)
    AND is_primary = 1 -- primary addresses only
   */

  /**
   * Construct the search query
   */
  function all($offset = 0, $rowcount = 0, $sort = null, $includeContactIDs = false, $onlyIDs = false) {

    $select = '
        cc.id, CONCAT_WS(" ", first_name, last_name) as name, 
        street_address, 
        supplemental_address_1, 
        supplemental_address_2, 
        city, 
        csp.abbreviation as State, 
        postal_code, 
        country.name as Country  
                ';

    $from = $this->from();

    // Needs the parameter but it is not used.
    $where = $this->where($includeContactIDs);

    if (!empty($where)) {
      $where = "WHERE $where";
    }

    $sql = " SELECT $select FROM   $from $where ";
    return $sql;
  }

  /**
   * Add a join and where condition limiting contacts with activities matching the code. 
   * 
   * @param type $offset
   * @param type $rowcount
   * @param type $sort
   * @param type $includeContactIDs
   * @param type $onlyIDs
   * @return type
   */
  function catchup($tracking_code, $offset = 0, $rowcount = 0, $sort = null, $includeContactIDs = false, $onlyIDs = false) {
    $sql = $this->all($offset = 0, $rowcount = 0, $sort = null, $includeContactIDs = false, $onlyIDs = false);

    $sql .= "AND NOT cc.id IN (
    SELECT target_contact_id FROM civicrm_option_value cov
        LEFT JOIN civicrm_activity activity ON activity.activity_type_id = cov.`value`
        LEFT JOIN civicrm_activity_target cat ON cat.activity_id = activity.id 
        LEFT JOIN civicrm_value_esa_journal_tracking_14 tracking ON tracking.entity_id = activity.id
        WHERE cov.name = '";
    $sql .= EmrJournaltrackingVal::ACTIVITY_TYPE_NAME;
    $sql .= "'
            AND tracking.batch_id_101 = '" . $tracking_code . "'
)";

    return $sql;
  }

  /**
   * Alters the date display in the Activity Date Column. We do this after we already have 
   * the result so that sorting on the date column stays pertinent to the numeric date value
   * @param type $row
   */
  function alterRow(&$row) {
    // $row['activity_date'] = CRM_Utils_Date::customFormat($row['activity_date'], '%B %E%f, %Y %l:%M %P');
  }

  // Regular JOIN statements here to limit results to contacts who have activities.
  function from() {
    return "
      civicrm_contact cc   
        LEFT JOIN civicrm_address ca ON cc.id = ca.contact_id 
        LEFT JOIN civicrm_membership cm ON cc.id = cm.contact_id
        LEFT JOIN civicrm_state_province csp ON ca.state_province_id = csp.id
        LEFT JOIN civicrm_country country ON ca.country_id = country.id";
  }

  /**
   * WHERE clause is an array built from any required JOINS plus conditional filters based on search criteria field values
   *
   */
  function where($includeContactIDs = FALSE) {
    $clauses = array();

    $clauses[] = "cm.membership_type_id IN (" . EmrJournaltrackingVal::MEMBERSHIP_TYPES . ")";
    $clauses[] = "cm.status_id IN (" . EmrJournaltrackingVal::MEMBERSHIP_STATUSES . ")";
    $clauses[] = "cm.is_test = 0";
    $clauses[] = "cc.is_deleted = 0";
    $clauses[] = "is_primary = 1";

    // add where for batch date.
    return implode(' AND ', $clauses);
  }

  /**
   * Functions below generally don't need to be modified
   */
  function count() {
    $sql = $this->all();

    $dao = CRM_Core_DAO::executeQuery($sql, CRM_Core_DAO::$_nullArray);
    return $dao->N;
  }

  function contactIDs($offset = 0, $rowcount = 0, $sort = null) {
    return $this->all($offset, $rowcount, $sort, false, true);
  }

  function &columns() {
    return $this->_columns;
  }

  function summary() {
    return null;
  }

}